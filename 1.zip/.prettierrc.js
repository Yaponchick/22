module.exports = {
	semi: true,
	trailingComma: 'es5',
	singleQuote: true,
	jsxSingleQuote: true,
	bracketSameLine: true,
	printWidth: 80,
	useTabs: true,
	tabWidth: 2,
	endOfLine: 'lf',
};
