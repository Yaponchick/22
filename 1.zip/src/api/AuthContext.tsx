import React, { createContext, useState, useEffect, FC, ReactNode } from 'react';

//  Интерфейс для контекста авторизации 
interface AuthContextType {
    isLoggedIn: boolean;
    login: () => void;
    logout: () => void;
}

//  Создание контекста с типом 
export const AuthContext = createContext<AuthContextType | undefined>(undefined);

//  Пропсы для AuthProvider 
interface AuthProviderProps {
    children: ReactNode;
}

//  Компонент AuthProvider 
export const AuthProvider: FC<AuthProviderProps> = ({ children }) => {
    const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);

    // Проверка авторизации при монтировании
    useEffect(() => {
        const token = localStorage.getItem('access_token');
        if (token) {
            setIsLoggedIn(true);
        }
    }, []);

    const login = () => {
        setIsLoggedIn(true);
    };

    const logout = () => {
        localStorage.removeItem('access_token');
        localStorage.removeItem('refresh_token');
        setIsLoggedIn(false);
    };

    return (
        <AuthContext.Provider value={{ isLoggedIn, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};