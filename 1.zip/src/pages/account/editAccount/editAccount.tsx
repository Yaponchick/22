// UserPhoto.tsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

interface UserPhotoProps {
    userId: number;
    currentPhotoUrl?: string;
    onPhotoUpdated: (newUrl: string) => void;
}

const UserPhoto: React.FC<UserPhotoProps> = ({ userId, currentPhotoUrl, onPhotoUpdated }) => {
    const [photoUrl, setPhotoUrl] = useState(currentPhotoUrl);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        setPhotoUrl(currentPhotoUrl);
    }, [currentPhotoUrl]);

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!e.target.files || e.target.files.length === 0) return;

        const file = e.target.files[0];
        const formData = new FormData();
        formData.append('file', file);

        try {
            setIsLoading(true);
            setError('');

            const response = await axios.post('/user/upload-photo', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            setPhotoUrl(response.data.photoUrl);
            onPhotoUpdated(response.data.photoUrl);
        } catch (err) {
            setError('Ошибка при загрузке фото. Пожалуйста, попробуйте еще раз.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="user-photo-container">
            {photoUrl ? (
                <img 
                    src={photoUrl} 
                    alt="User" 
                    className="user-photo"
                    onError={() => setPhotoUrl(undefined)}
                />
            ) : (
                <div className="user-photo-placeholder">No photo</div>
            )}
            
            <div className="photo-upload-controls">
                <input
                    type="file"
                    id="photo-upload"
                    accept="image/jpeg,image/png"
                    onChange={handleFileChange}
                    disabled={isLoading}
                    style={{ display: 'none' }}
                />
                <label htmlFor="photo-upload" className="upload-button">
                    {isLoading ? 'Загрузка...' : photoUrl ? 'Изменить фото' : 'Загрузить фото'}
                </label>
                {error && <div className="error-message">{error}</div>}
            </div>
        </div>
    );
};

export default UserPhoto;