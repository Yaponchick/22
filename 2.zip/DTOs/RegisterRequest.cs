﻿using questionnaire.questionnaire.Authentication;

namespace Web.DTOs
{
    public class RegisterRequest
    {
        public string Username { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string Password { get; set; } = null!;
        public int AccessLevelId { get; set; } = AuthOptions.RespondentRoleId;
    }
}
