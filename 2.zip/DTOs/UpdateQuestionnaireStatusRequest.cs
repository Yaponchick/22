﻿namespace questionnaire.questionnaire.DTOs
{
    public class UpdateQuestionnaireStatusRequest
    {
        public bool IsPublished { get; set; }
    }
}
