﻿namespace questionnaire.questionnaire.DTOs
{
    public class UpdateQuestionnaireTitleRequest
    {
        public string NewTitle { get; set; } = null!;
    }
}
