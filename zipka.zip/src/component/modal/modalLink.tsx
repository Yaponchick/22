import React, { useState, useEffect } from 'react';

import './modalLink.css'

import CopyIcon from '../../img/SurveyPage/CopyIcon.png';
import VkIcon from '../../img/SurveyPage/VkIcon.png';
import WhatsappIcon from '../../img/SurveyPage/WhatsappIcon.png';
import TelegramIcon from '../../img/SurveyPage/TelegramIcon.png';
import DeleteIcons from '../../img/SurveyPage/DeleteIcons.png';


interface ModalLinkProps {
    isOpen: boolean;
    onClose: () => void;
    link: string | null;
}
interface PopupState {
    visible: boolean;
    text: string;
    x: number;
    y: number;
}
const ModalLink: React.FC<ModalLinkProps> = ({ isOpen, onClose, link }) => {
    const [popup, setPopup] = useState<PopupState>({ visible: false, text: '', x: 0, y: 0 });

    if (!isOpen) return null;

    // const handleCopy = () => {
    //     if (link) navigator.clipboard.writeText(link);
    // };

    const showPopup = (text: string, event: React.MouseEvent | null): void => {
        const xPos = event ? event.clientX : window.innerWidth / 2;
        const yPos = event ? event.clientY : window.innerHeight / 2;
        setPopup({ visible: true, text, x: xPos, y: yPos });
        setTimeout(() => {
            setPopup((prev) => ({ ...prev, visible: false }));
        }, 1800);
    };

    const handleCopy = (event: React.MouseEvent): void => {
        if (!link) return;
        navigator.clipboard
            .writeText(link)
            .then(() => {
                showPopup('Ссылка скопирована!', event);
            })
            .catch((err: unknown) => {
                console.error('Ошибка копирования ссылки:', err);
                showPopup('Ошибка копирования', event);
            });
    };

    return (
        <div className='modal' onClick={onClose}>
            <div className='modal-content' onClick={(e) => e.stopPropagation()}>
                <div className='modal-text'>
                    <div className='textAndDel'>
                        Поделиться
                        <div className="closeIcon">
                            <img src={DeleteIcons} alt="Закрыть" className='closeButtonIcon' onClick={onClose} />
                        </div>
                    </div>
                    <hr />
                    <div className='titleLink'>
                        <div className="survey-titleLink">
                            <span className="link-text">{link}</span>
                        </div>
                        <img
                            src={CopyIcon}
                            alt="Копировать ссылку"
                            title="Копировать ссылку"
                            className="Copy icon-button"
                            onClick={handleCopy}
                        />
                    </div>
                    <div className='textModalQR'>
                        Скачайте QR-код с ссылкой на эту анкету, чтобы <br />
                        использовать в своих презентациях, отчетах <br />
                        или иных документах
                    </div>
                    <div className="qr-image-wrapper">
                        <img
                            src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(link || 'stateLink')}`}
                            alt="QR Code"
                            className="qr-image"
                        />
                    </div>
                </div>
                <div className='footer-modal'>
                    Отправить через соцсеть
                    <div className='icon-web'>
                        <img src={VkIcon} alt="VK" />
                        <img src={TelegramIcon} alt="Telegram" />
                        <img src={WhatsappIcon} alt="WhatsApp" />
                    </div>
                </div>
            </div>
            {popup.visible && (
                <div
                    className="copy-popup"
                    style={{ top: popup.y +20, left: popup.x - 130 }}
                >
                    {popup.text}
                </div>
            )}
        </div>
    );
};

export default ModalLink;
