import { useState, useEffect, useRef, useCallback, useMemo, DragEvent, SetStateAction, Dispatch } from 'react';
import { useNavigate, NavigateFunction } from 'react-router-dom';
import apiClient from '../../api/apiClient';
import { AxiosInstance } from 'axios';

const ANIMATION_DURATION = 450;

// Определяем типы для вопросов, ответов и ошибок
type QuestionType = "Открытый" | "Закрытый" | "Множественный выбор" | "Шкала" | "Выпадающий список";

interface Answer {
    id: string;
    text: string;
}

interface Question {
    uniqueId: string;
    displayId: number;
    type: QuestionType;
    text: string;
    answers: Answer[];
    leftScaleValue: string;
    rightScaleValue: string;
    divisions: number;
    isNew: boolean;
    isDeleting: boolean;
    animationState: string | null;
}

interface QuestionErrors {
    [key: number]: string;
}

// Определяем тип для apiClient
const typedApiClient: AxiosInstance = apiClient;

export const useSurvey = () => {
    const navigate: NavigateFunction = useNavigate();

    const [questions, setQuestions] = useState<Question[]>([]);
    const [title, setTitle] = useState<string>("");
    const [draggedId, setDraggedId] = useState<string | null>(null);
    const [dragOverId, setDragOverId] = useState<string | null>(null);
    const [dropdownsOpen, setDropdownsOpen] = useState<{ [key: string]: boolean }>({});
    const [error, setError] = useState<string>("");
    const [questionErrors, setQuestionErrors] = useState<QuestionErrors>({});
    const [deleteError, setDeleteError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);

    const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
    const [pendingQuestions, setPendingQuestions] = useState<Question[] | null>(null);

    const questionRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});

    const questionIndices = useMemo(() => {
        const indices: { [key: string]: number } = {};
        questions.forEach((q, index) => {
            indices[q.uniqueId] = index;
        });
        return indices;
    }, [questions]);

    const draggedIndex = useMemo(() => (draggedId ? questionIndices[draggedId] : -1), [draggedId, questionIndices]);

    const setQuestionRef = (id: string, element: HTMLDivElement | null) => {
        if (element) {
            questionRefs.current[id] = element;
        } else {
            delete questionRefs.current[id];
        }
    };

    const updateDisplayIds = (currentQuestions: Question[]): Question[] => {
        return currentQuestions.map((q, index) => ({
            ...q,
            displayId: index + 1,
        }));
    };

    const clearAnimationState = (uniqueId: string) => {
        setQuestions(prev => prev.map(q =>
            q.uniqueId === uniqueId && q.animationState ? { ...q, animationState: null } : q
        ));
    };

    useEffect(() => {
        questions.forEach(q => {
            if (q.isNew) {
                const element = questionRefs.current[q.uniqueId];
                if (element) {
                    element.classList.add('question-enter');
                    requestAnimationFrame(() => {
                        element.classList.remove('question-enter');
                    });
                }
                const timer = setTimeout(() => {
                    setQuestions(prev => prev.map(pq => pq.uniqueId === q.uniqueId ? { ...pq, isNew: false } : pq));
                }, ANIMATION_DURATION);
                return () => clearTimeout(timer);
            }
        });
    }, [questions]);

    useEffect(() => {
        if (dragOverId === null) {
            setQuestions(prev => prev.map(q =>
                q.animationState?.startsWith('make-space') ? { ...q, animationState: null } : q
            ));
        }
    }, [dragOverId]);

    const getQuestionTypeId = (type: QuestionType): number => {
        switch (type) {
            case "Открытый": return 1;
            case "Закрытый": return 2;
            case "Множественный выбор": return 3;
            case "Шкала": return 4;
            case "Выпадающий список": return 5;
            default: throw new Error(`Неизвестный тип вопроса: ${type}`);
        }
    };

    const validateQuestions = (): boolean => {
        const errors: QuestionErrors = {};
        let isValid = true;

        if (!title.trim()) {
            setError("Название анкеты должно быть заполнено");
            isValid = false;
        } else if (title.length > 250) {
            setError("Название анкеты не может превышать 250 символов");
            isValid = false;
        }

        questions.forEach((question) => {
            if (question.isDeleting) return;
            const errorKey = question.displayId;

            if (!question.text.trim() && question.type !== "Шкала") {
                errors[errorKey] = "Текст вопроса не может быть пустым";
                isValid = false;
            } else if (question.text.length > 250) {
                errors[errorKey] = "Текст вопроса не может превышать 250 символов";
                isValid = false;
            }

            if (question.type === "Шкала") {
                const hasLeft = question.leftScaleValue.trim();
                const hasRight = question.rightScaleValue.trim();

                if (!hasLeft) {
                    errors[errorKey] = "Левое значение шкалы обязательно";
                    isValid = false;
                } else if (!hasRight) {
                    errors[errorKey] = "Правое значение шкалы обязательно";
                    isValid = false;
                } else if (question.divisions < 2) {
                    errors[errorKey] = "Минимум 2 деления";
                    isValid = false;
                } else if (question.divisions > 10) {
                    errors[errorKey] = "Максимум 10 делений";
                    isValid = false;
                } else if (question.leftScaleValue.length > 250 || question.rightScaleValue.length > 250) {
                    errors[errorKey] = "Значения шкалы не могут превышать 250 символов";
                    isValid = false;
                }
            }

            if (["Закрытый", "Множественный выбор", "Выпадающий список"].includes(question.type)) {
                if (!question.answers || question.answers.length < 2) {
                    errors[errorKey] = "Необходимо как минимум два варианта ответа";
                    isValid = false;
                } else {
                    const emptyAnswers = question.answers.filter(a => !a.text.trim());
                    if (emptyAnswers.length > 0) {
                        errors[errorKey] = "Варианты ответов не могут быть пустыми";
                        isValid = false;
                    } else {
                        const invalidAnswers = question.answers.filter(a => a.text.length > 250);
                        if (invalidAnswers.length > 0) {
                            errors[errorKey] = "Варианты ответов не могут превышать 250 символов";
                            isValid = false;
                        }
                    }
                }
            }
        });

        setQuestionErrors(errors);
        return isValid;
    };

    const addQuestionApi = async (questionnaireId: string, question: Question) => {
        try {
            const response = await typedApiClient.post(`/questionnaire/${questionnaireId}/questions/add-question`, {
                Text: question.text,
                QuestionType: getQuestionTypeId(question.type),
            });
            const questionId = response.data.questionId;

            if (["Закрытый", "Множественный выбор", "Выпадающий список"].includes(question.type) && question.answers?.length > 0) {
                for (const answer of question.answers) {
                    if (answer.text.trim()) {
                        await typedApiClient.post(`/questionnaire/${questionnaireId}/questions/${questionId}/options`, {
                            OptionText: answer.text,
                        });
                    }
                }
            }
        } catch (error: any) {
            console.error('Ошибка при добавлении вопроса (API):', error.response?.data || error.message);
            throw new Error(`Ошибка добавления вопроса "${question.text.substring(0, 20)}...": ${error.response?.data?.message || error.message}`);
        }
    };

    const handleSaveClick = () => {
        if (isLoading) return;

        // Сброс ошибок
        setError("");
        setQuestionErrors({});

        // Валидация
        if (questions.length === 0) {
            setError("Добавьте хотя бы один вопрос");
            return;
        }

        if (!validateQuestions()) {
            return;
        }

        // Сохраняем состояние вопросов и показываем модальное окно
        setPendingQuestions(questions.filter(q => !q.isDeleting));
        setIsModalOpen(true);
    };

    const confirmSave = async (): Promise<string | undefined> => {
        if (!pendingQuestions || isLoading) return;

        setIsLoading(true);
        try {
            const formattedQuestions = pendingQuestions.map((question) => {
                const cleanQuestion = { ...question, animationState: null };
                if (cleanQuestion.type === "Шкала") {
                    const scaleText = `${cleanQuestion.leftScaleValue || ""}|${cleanQuestion.rightScaleValue || ""}|${cleanQuestion.divisions || 5}`;
                    return { ...cleanQuestion, text: `${cleanQuestion.text || ''}|${scaleText}` };
                }
                return cleanQuestion;
            });

            const response = await typedApiClient.post('/questionnaire/create', { Title: title });
            const questionnaireId = response.data.questionnaireId;
            const link = response.data.link; // <-- ССЫЛКА

            // Сохраняем вопросы
            for (const question of formattedQuestions.sort((a, b) => a.displayId - b.displayId)) {
                await addQuestionApi(questionnaireId, question);
            }

            setIsModalOpen(false);
            setPendingQuestions(null);
            
            return link;

        } catch (error: any) {
            console.error('Ошибка при сохранении анкеты:', error.response?.data || error.message);
            setError(`Ошибка при сохранении анкеты: ${error.response?.data?.message || error.message}`);
        } finally {
            setIsLoading(false);
        }
    };


    const cancelSave = () => {
        setIsModalOpen(false);
        setPendingQuestions(null);
    };

    const handleDragStart = useCallback((e: DragEvent<HTMLDivElement>, uniqueId: string) => {
        e.dataTransfer.effectAllowed = 'move';
        setDraggedId(uniqueId);
        setTimeout(() => {
            const element = questionRefs.current[uniqueId];
            if (element) element.classList.add('dragging');
        }, 0);
    }, []);

    const handleDragOver = useCallback((e: DragEvent<HTMLDivElement>, targetUniqueId: string) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        if (targetUniqueId === draggedId) {
            if (dragOverId && dragOverId !== targetUniqueId) clearAnimationState(dragOverId);
            setDragOverId(null);
            return;
        }
        if (targetUniqueId !== dragOverId) {
            if (dragOverId) clearAnimationState(dragOverId);
            setDragOverId(targetUniqueId);
            const targetIndex = questionIndices[targetUniqueId];
            if (draggedIndex !== -1 && targetIndex !== -1) {
                const direction = draggedIndex < targetIndex ? 'make-space-up' : 'make-space-down';
                setQuestions(prev => prev.map(q => q.uniqueId === targetUniqueId ? { ...q, animationState: direction } : q));
            }
        }
    }, [draggedId, dragOverId, questionIndices, draggedIndex]);

    const handleDragLeave = useCallback((e: DragEvent<HTMLDivElement>, uniqueId: string) => {
        const container = questionRefs.current[uniqueId];
        if (container && !container.contains(e.relatedTarget as Node)) {
            if (uniqueId === dragOverId) {
                clearAnimationState(uniqueId);
                setDragOverId(null);
            }
        }
    }, [dragOverId]);

    const handleDrop = useCallback((e: DragEvent<HTMLDivElement>, targetUniqueId: string) => {
        e.preventDefault();
        if (!draggedId || draggedId === targetUniqueId) {
            if (dragOverId) clearAnimationState(dragOverId);
            setDragOverId(null);
            if (draggedId && questionRefs.current[draggedId]) {
                questionRefs.current[draggedId]?.classList.remove('dragging');
            }
            setDraggedId(null);
            return;
        }
        const targetIndex = questionIndices[targetUniqueId];
        if (draggedIndex === -1 || targetIndex === -1) return;
        clearAnimationState(targetUniqueId);
        setQuestions(prevQuestions => {
            const updatedQuestions = [...prevQuestions];
            const [draggedItem] = updatedQuestions.splice(draggedIndex, 1);
            const cleanDraggedItem = { ...draggedItem, animationState: null, isNew: false, isDeleting: false };
            updatedQuestions.splice(targetIndex, 0, cleanDraggedItem);
            return updateDisplayIds(updatedQuestions.map(q => ({ ...q, isNew: false, isDeleting: false })));
        });
        if (questionRefs.current[draggedId]) {
            questionRefs.current[draggedId]?.classList.remove('dragging');
        }
        setDraggedId(null);
        setDragOverId(null);
    }, [draggedId, draggedIndex, questionIndices]);

    const handleDragEnd = useCallback(() => {
        if (draggedId && questionRefs.current[draggedId]) {
            questionRefs.current[draggedId]?.classList.remove('dragging');
        }
        if (dragOverId) clearAnimationState(dragOverId);
        setDraggedId(null);
        setDragOverId(null);
    }, [draggedId, dragOverId]);

    const handleAddFirstQuestion = (type: QuestionType) => {
        const newQuestion: Question = {
            uniqueId: `q_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
            displayId: 1, type, text: "", answers: [],
            leftScaleValue: "", rightScaleValue: "", divisions: 5,
            isNew: true, isDeleting: false, animationState: null,
        };
        if (["Закрытый", "Множественный выбор", "Выпадающий список"].includes(type)) {
            newQuestion.answers = [{ id: `a_${Date.now()}_1`, text: "" }, { id: `a_${Date.now()}_2`, text: "" }];
        }
        setQuestions([newQuestion]);
    };

    const addNewQuestion = (afterUniqueId: string, type: QuestionType = "Открытый") => {
        if (questions.filter(q => !q.isDeleting).length >= 10) return;

        const newQuestion: Question = {
            uniqueId: `q_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
            displayId: 0,
            type,
            text: "",
            answers: [],
            leftScaleValue: "",
            rightScaleValue: "",
            divisions: 5,
            isNew: true,
            isDeleting: false,
            animationState: null,
        };

        // Добавляем ответы по умолчанию для нужных типов
        if (["Закрытый", "Множественный выбор", "Выпадающий список"].includes(type)) {
            newQuestion.answers = [
                { id: `a_${Date.now()}_1`, text: "" },
                { id: `a_${Date.now()}_2`, text: "" }
            ];
        }

        setQuestions(prevQuestions => {
            const index = prevQuestions.findIndex(q => q.uniqueId === afterUniqueId);
            const insertIndex = index !== -1 ? index + 1 : prevQuestions.length;
            const updatedQuestions = [...prevQuestions];
            updatedQuestions.splice(insertIndex, 0, newQuestion);
            return updateDisplayIds(updatedQuestions);
        });
    };

    const moveQuestion = useCallback((uniqueId: string, direction: 'up' | 'down') => {
        const index = questionIndices[uniqueId];
        let targetIndex = -1;
        if (direction === 'up' && index > 0) targetIndex = index - 1;
        else if (direction === 'down' && index < questions.length - 1) targetIndex = index + 1;

        if (targetIndex !== -1) {
            setQuestions(prev => {
                const updated = [...prev];
                [updated[index], updated[targetIndex]] = [updated[targetIndex], updated[index]];
                return updateDisplayIds(updated);
            });
        }
    }, [questions, questionIndices]);

    const deleteQuestion = useCallback((uniqueId: string) => {
        setQuestions(prev => prev.map(q => q.uniqueId === uniqueId ? { ...q, isDeleting: true, animationState: null } : q));
        setTimeout(() => {
            setQuestions(prev => updateDisplayIds(prev.filter(q => q.uniqueId !== uniqueId)));
            delete questionRefs.current[uniqueId];
        }, ANIMATION_DURATION);
    }, [questions]);

    const handleOptionSelect = (uniqueId: string, option: QuestionType) => {
        setQuestions(questions.map((q) =>
            q.uniqueId === uniqueId ? {
                ...q, type: option,
                answers: ["Закрытый", "Множественный выбор", "Выпадающий список"].includes(option) && q.answers.length === 0
                    ? [{ id: `a_${Date.now()}_1`, text: "" }, { id: `a_${Date.now()}_2`, text: "" }]
                    : (["Закрытый", "Множественный выбор", "Выпадающий список"].includes(option) ? q.answers : []),
                leftScaleValue: option === "Шкала" ? q.leftScaleValue : "",
                rightScaleValue: option === "Шкала" ? q.rightScaleValue : "",
                divisions: option === "Шкала" ? q.divisions : 5,
                animationState: null,
            } : q
        ));
        const questionWithError = questions.find(q => q.uniqueId === uniqueId);
        if (questionWithError) {
            setQuestionErrors(prev => {
                const newErrors = { ...prev };
                delete newErrors[questionWithError.displayId];
                return newErrors;
            });
        }
        setDropdownsOpen(prev => ({ ...prev, [uniqueId]: false }));
    };

    const addAnswer = (questionUniqueId: string) => {
        setQuestions(questions.map((q) => {
            if (q.uniqueId === questionUniqueId) {
                if (q.answers.length >= 10) {
                    setDeleteError("Нельзя добавить больше 10 ответов");
                    setTimeout(() => setDeleteError(null), 3000);
                    return q;
                }
                const newAnswer: Answer = { id: `a_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`, text: "" };
                return { ...q, answers: [...(q.answers || []), newAnswer] };
            }
            return q;
        }));
    };

    const deleteAnswer = (questionUniqueId: string, answerIdToDelete: string) => {
        setQuestions(prev => prev.map((q) => {
            if (q.uniqueId === questionUniqueId) {
                if (q.answers.length <= 2) {
                    setDeleteError("Минимум 2 ответа");
                    setTimeout(() => setDeleteError(null), 3000);
                    return q;
                }
                return { ...q, answers: q.answers.filter(a => a.id !== answerIdToDelete) };
            }
            return q;
        }));
    };

    const handleAnswerChange = (questionUniqueId: string, answerId: string, newText: string) => {
        setQuestions(questions.map(q =>
            q.uniqueId === questionUniqueId ? {
                ...q, answers: q.answers.map(a =>
                    a.id === answerId ? { ...a, text: newText } : a
                ),
            } : q
        ));
    };

    const handleQuestionTextChange = (uniqueId: string, newText: string) => {
        setQuestions(prev => prev.map(q => q.uniqueId === uniqueId ? { ...q, text: newText } : q));
    };

    const handleScaleChange = (uniqueId: string, field: keyof Question, value: string | number) => {
        setQuestions(prev => prev.map(q => q.uniqueId === uniqueId ? { ...q, [field]: value } : q));
    };

    return {
        questions,
        title,
        setTitle,
        error,
        questionErrors,
        deleteError,
        isLoading,
        dropdownsOpen,
        setDropdownsOpen,
        handleSaveClick,
        handleDragStart,
        handleDragOver,
        handleDrop,
        handleDragEnd,
        handleDragLeave,
        handleAddFirstQuestion,
        addNewQuestion,
        deleteQuestion,
        moveQuestion,
        setQuestionRef,
        handleOptionSelect,
        addAnswer,
        deleteAnswer,
        handleAnswerChange,
        handleQuestionTextChange,
        handleScaleChange,
        setDeleteError,
        isModalOpen,
        confirmSave,
        cancelSave,
    };
};