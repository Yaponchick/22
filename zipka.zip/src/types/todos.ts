export interface Todo {
	id: string;
	name: string;
	isComplete: boolean;
}
