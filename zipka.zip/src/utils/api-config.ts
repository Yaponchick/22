export const apiConfig = {
	baseUrl: 'https://tsa-web07-id.ie.corp:4007/api',
	baseUrlAuth: 'https://tsa-web07-id.ie.corp:4009/api',
};
